Liferay.Service.register("Liferay.Service.TY", "org.tvd.thptty.service");

Liferay.Service.registerClass(
	Liferay.Service.TY, "Semester",
	{
		addSemster: true
	}
);