package org.tvd.thptty.management.temporary;

public interface Column {
	public static final String fullName = "Ho va ten";
	public static final String studentId = "Ma hoc sinh";
	public static final String SPEAK_POINT = "Diem mieng";
	public static final String WRITE_15_POINT = "Diem 15ph";
	public static final String WRITE_45_POINT = "Diem 45ph";
	public static final String WRITE_90_POINT = "HK";
}
