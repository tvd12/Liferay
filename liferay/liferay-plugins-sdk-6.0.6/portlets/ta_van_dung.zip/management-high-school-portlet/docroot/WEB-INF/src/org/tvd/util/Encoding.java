package org.tvd.util;

public interface Encoding {
	public static final String DEFAULT_ENCODING="UTF-8";
}
