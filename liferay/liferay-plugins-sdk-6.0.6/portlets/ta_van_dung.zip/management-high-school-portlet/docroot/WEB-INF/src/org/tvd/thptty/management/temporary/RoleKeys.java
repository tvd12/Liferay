package org.tvd.thptty.management.temporary;

public interface RoleKeys {
	public static final int MANAGEMENT = 1101;
	public static final int TYPE_POINT = 1102;
	public static final int SUBJECT_CAPITAL = 1103;
}
