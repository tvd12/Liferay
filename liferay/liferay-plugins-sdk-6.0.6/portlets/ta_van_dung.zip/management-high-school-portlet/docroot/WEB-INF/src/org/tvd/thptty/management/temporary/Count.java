package org.tvd.thptty.management.temporary;

public class Count {
	public static long COUNT = 1;
}
