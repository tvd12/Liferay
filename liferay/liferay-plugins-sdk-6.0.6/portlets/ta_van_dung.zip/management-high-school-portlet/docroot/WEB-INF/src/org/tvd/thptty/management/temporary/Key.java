package org.tvd.thptty.management.temporary;

public interface Key {
	public static final String KEY = "cam on tat ca moi nguoi";
}
