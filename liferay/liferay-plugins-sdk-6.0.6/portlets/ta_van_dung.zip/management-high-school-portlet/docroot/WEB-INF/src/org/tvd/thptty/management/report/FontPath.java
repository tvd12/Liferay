package org.tvd.thptty.management.report;

public interface FontPath {
	public static final String TAHOMA_FONT = "fonts/tahoma.ttf";
}
