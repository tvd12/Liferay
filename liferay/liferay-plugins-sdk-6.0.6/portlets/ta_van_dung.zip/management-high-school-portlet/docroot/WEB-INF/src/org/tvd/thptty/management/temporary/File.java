package org.tvd.thptty.management.temporary;

public interface File {
	public static final long MAX_FILE_SIZE = 1000 * 1000;
}
